<?php
/* Displays all error messages */
session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Congrats</title>
  <?php include 'css/css.html'; ?>
</head>
<body>
<div class="form">
    <h1>Congratulations !!</h1>
    <p>
    <h2 style="padding-left:23%;"><b>You are successfully Registered</b></h2>
    </p>     
    <a href="login.php"><button class="button button-block"/>Go to Login</button></a>
</div>
</body>
</html>